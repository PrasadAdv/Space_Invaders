import pygame
import random
import math
from pygame import mixer
import numpy as np

pygame.init()
flag=0
screen=pygame.display.set_mode((800,600))

pygame.display.set_caption('Space Adventures')

mixer.music.load('chill-ambient-11322.mp3')
mixer.music.play(-1)
icon=pygame.image.load('space-invaders.png')

backgroundimg=pygame.image.load('space.png')
background=pygame.transform.scale(backgroundimg,(800,600))
pygame.display.set_icon(icon)

playerimg=pygame.transform.scale(icon,(80,80))
playerX=370
playerY=480

count=6
enemyimgg=[]
enemyX=[]
enemyY=[]
enemyX_change=[]
enemyY_change=[]
exception=[]
enemyimg=np.array(enemyimgg)

def ene():
    enemy=pygame.image.load('alien.png')
    for i in range(count):   
        enemyimgg.append(pygame.transform.scale(enemy,(80,80)))
        enemyX.append(random.randint(0,720))
        enemyY.append(random.randint(0,150))
        enemyX_change.append(3)
        enemyY_change.append(20)
    global enemyimg
    enemyimg=np.array(enemyimgg)
ene()
global missileX, missileY
missile=pygame.image.load('missile.png')
missileimg=pygame.transform.scale(missile,(40,80))
missileX=playerX
missileY=playerY

X_change=0
Y_change=0

missileY_change=8
missile_state='ready'
score_value=0
blast_state='ready'
plblast_state='ready'
font=pygame.font.Font('freesansbold.ttf',25)
scoreX=10
scoreY=10

over_font=pygame.font.Font('freesansbold.ttf',35)

def score(x,y):
    score=font.render('SCORE: '+ str(score_value), True ,(255,255,255))
    screen.blit(score,(x,y))

def game_over():
    global flag
    over=over_font.render('GAME OVER', True ,(255,255,255))
    flag=1
    screen.blit(over,(300,250))
    
def player(x,y):
    screen.blit(playerimg,(x,y))

def enemy(x,y,i):
    screen.blit(enemyimg[i],(x,y))

def fire(x,y):
    global missile_state
    missile_state='fire'
    screen.blit(missileimg,(x+20,y))
    
def iscollision(x1,y1,x2,y2):
    distance=math.sqrt((math.pow((x1-x2),2))+(math.pow((y1-y2),2)))  
    if distance<=27:
        return True
    else:
        return False

def plcollision(x1,y1,x2,y2):
    distance=math.sqrt((math.pow((x1-x2),2))+(math.pow((y1-y2),2)))  
    if distance<=27:
        return True
    else:
        return False
    
def lev():
    fonti=pygame.font.Font('freesansbold.ttf',25)
    if count<=6:        
        level=fonti.render('Level 1', True ,(255,255,255))
    elif count>6 and count<=16:
        level=fonti.render('Level 2', True ,(255,255,255))
    screen.blit(level,(700,10))

blast_ani=[]
for i in range(1,56):
    blas=pygame.image.load('Sprites/no_'+str(i)+'.png')
    blast_ani.append(pygame.transform.scale(blas,(100,100)))
clock=pygame.time.Clock()

value=0
def blast_anim(x,y):
    global value
    global blast_state
    blast_state='fire'
    if value>=len(blast_ani):
        value=0
    blast_im=blast_ani[value]        
    screen.blit(blast_im,(x,y))
    value+=1

plblast_ani=[]
for i in range(1,56):
    plblas=pygame.image.load('Sprites/no_'+str(i)+'.png')
    plblast_ani.append(pygame.transform.scale(plblas,(150,150)))

plvalue=0
def plblast_anim(x,y):
    global playerimg
    global plvalue
    global plblast_state
    plblast_state='fire'
    playerimg=plblast_ani[plvalue]        
    screen.blit(playerimg,(x,y))
    if plvalue>=len(plblast_ani):
        game_over()
    plvalue+=1

running=True

while running:
    
    screen.fill((0,0,0))
    screen.blit(background,(0,0))
    for event in pygame.event.get():
        
        if event.type==pygame.QUIT:
            running=False

        if flag==1:
            running==False
        elif event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                X_change=-4
            if event.key==pygame.K_RIGHT:
                X_change=+4
            if event.key==pygame.K_UP:
                Y_change=-4
            if event.key==pygame.K_DOWN:
                Y_change=+4
            if event.key==pygame.K_SPACE:
                if missile_state=='ready':
                    global sp
                    sp=1
                    missile_sound=mixer.Sound('missilefire.mp3')
                    missile_sound.play()
                    missileX=playerX
                    missileY=playerY
                    fire(missileX,missileY)
         
        if event.type==pygame.KEYUP:
            if event.key==pygame.K_LEFT or event.key==pygame.K_RIGHT or event.key==pygame.K_UP or event.key==pygame.K_DOWN:
                X_change=0
                Y_change=0
    lev()                        
    playerX+=X_change
    playerY+=Y_change
    
    if playerX<=0:
        playerX=0
    if playerX>=720:
        playerX=720
    if playerY<=0:
        playerY=0
    if playerY>=520:
        playerY=520

    for i in range(count):
        if i in exception:
            continue
        else:            
            if enemyY[i]>350:
                for j in range(count):
                    enemyY[j]=2000
                game_over()
                break        
            enemyX[i]+=enemyX_change[i]    

            if enemyX[i]<=0:
                enemyX_change[i]=3
                enemyY[i]+=enemyY_change[i]
            if enemyX[i]>=720:
                enemyX_change[i]=-3
                enemyY[i]+=enemyY_change[i]

            collision=iscollision(enemyX[i],enemyY[i],missileX,missileY)

            if collision and sp==1:
                global k
                collision_sound=mixer.Sound('blast.mp3')
                collision_sound.play()
                blast_anim(enemyX[i],enemyY[i])
                k=i
                missileY=playerY                
                missile_state='ready'
                score_value+=1
                enemyimg[i]=''
                exception.append(i)
                sp=0
            else:
                enemy(enemyX[i],enemyY[i],i)
    
            player_collision=plcollision(enemyX[i],enemyY[i],playerX,playerY)

        if player_collision:
            for j in range(count):
                enemyY[j]=2000
            collision_sound=mixer.Sound('blast.mp3')
            collision_sound.play()
            plblast_anim(playerX,playerY)
            break        

    if missileY<=0:
        missileY=playerY
        missileX=playerX
        missile_state='ready'        

    if missile_state is 'fire':
        fire(missileX,missileY)
        missileY-=missileY_change
        
    if blast_state is 'fire':
        blast_anim(enemyX[k],enemyY[k])
        if value==55:
            blast_state='ready'

    if plblast_state is 'fire':
        plblast_anim(playerX,playerY)
        if plvalue==55:
            plblast_state='ready'               
    
    player(playerX,playerY)
        
    score(scoreX,scoreY)
    
    if score_value==6:
        count=10
        exception.clear()
        ene()

    if score_value==16:
        game_over()
        
    pygame.display.update()
